Plot: 

Forrest Defense is a 3D tower defense game where are command various animals to defend the forest from evil creatures that wish to destroy your home. You must strategically place your units on the rocks lining the path through the forest so that they can defeat the invaders and keep the forest safe.  


Instructions:

- Left click on towers on the right side of the screen to select the tower you want to build
- Left click on a rock that you want the tower to be built on
- Left click on a built tower to either upgrade or sell it
- Towers will be built or upgraded if you have enough money to build or upgrade them
- Defeat the enemies that spawn from the spawning log preventing them from reaching the end
- Defeated enemies will give you money
- If your lives reach 0, you lose. 
- If you survive all the waves, you win!


Attributions:

Coin asset
- Allasstar
- https://assetstore.unity.com/packages/2d/environments/animated-2d-coins-22097

Animals, Enviornment, Sounds, Animations
- polyperfect
- https://assetstore.unity.com/packages/3d/characters/animals/low-poly-animated-animals-93089

Sell Sound
- artisticdude
- https://opengameart.org/content/rpg-sound-pack

Upgrade Sound

Spider Sound
- qubodup
- https://opengameart.org/content/fly-swatter-squish-sound